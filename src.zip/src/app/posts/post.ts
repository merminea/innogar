export class Post {
}

