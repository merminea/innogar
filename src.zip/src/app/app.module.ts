import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { Routes, RouterModule } from '@angular/router';

import { AppComponent } from './app.component';
import { PostListComponent } from './posts/post-list/post-list.component';

import { Wpng2RoutingModule } from './app-routing.module';
import { HeaderComponent } from './sections/header/header.component';
import { ProductComponent } from './sections/product/product.component';
import { FooterComponent } from './sections/footer/footer.component';
import { FutureComponent } from './sections/future/future.component';
import { LandingComponent } from './sections/landing/landing.component';
import { HomeComponent } from './home/home.component';



@NgModule({
  declarations: [
    AppComponent,
    PostListComponent,
    HeaderComponent,
    ProductComponent,
    FooterComponent,
    FutureComponent,
    LandingComponent,
    HomeComponent,
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    Wpng2RoutingModule,
    RouterModule.forRoot([
      { path:'home', component: HomeComponent, children: [  
        { path: 'landingcomp', component: LandingComponent, outlet: 'landing'},
        { path: 'productcomp', component: ProductComponent, outlet: 'product'},
        { path: 'futurecomp', component: FutureComponent, outlet: 'future'},
      ]},
      { path: 'about', component: PostListComponent},
      { path:'', redirectTo: 'home', pathMatch: 'full'},
      { path: '**', redirectTo: 'home', pathMatch: 'full'}
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }